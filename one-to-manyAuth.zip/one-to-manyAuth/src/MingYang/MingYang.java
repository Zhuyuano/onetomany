package MingYang;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class MingYang  {

    public static void setup(String pairingFile, String publicFile,String pkFile,String skFile,String GW) throws NoSuchAlgorithmException { //KMC do

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties pubProp =new Properties();
        pubProp.setProperty("P",P.toString());
        storePropToFile(pubProp,publicFile);
        //KMC为GW生成公钥和私钥
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        Element msk=bp.getZr().newRandomElement().getImmutable();
        Element GID=bp.getZr().newRandomElement().getImmutable();
        byte[] bH= sha1(GID+msk.toString());
        Element s=bp.getZr().newElementFromHash(bH,0,bH.length).getImmutable(); //私钥
        Element S=P.powZn(s).getImmutable(); //公钥
        //pkp.setProperty("S_"+GW,S.toString());
        pubProp.setProperty("S_"+GW,S.toString());
        skp.setProperty("s_"+GW,Base64.getEncoder().encodeToString(s.toBytes()));
        pubProp.setProperty("GID_"+GW,GID.toString());
        storePropToFile(pubProp,publicFile);
        storePropToFile(skp,skFile);
    }


    //Registration阶段
    public static void Registration_SD(String pairingFile,String publicFile,String pkFile,String skFile,String GW,String SD_j) throws NoSuchAlgorithmException {
    //KMC为智能设备生成密钥
        //获得P
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String GIDstr=pubProp.getProperty("GID_"+GW);
        Element GID=bp.getZr().newElementFromBytes(GIDstr.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        String sstr=skp.getProperty("s_"+GW); //获取网关的私钥
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sstr)).getImmutable();
        Element SID_j=bp.getZr().newRandomElement().getImmutable(); //KMC为智能设备选择身份
        byte[] bHj= sha1(SID_j+s.toString());
        Element skj=bp.getZr().newElementFromHash(bHj,0,bHj.length).getImmutable(); //SDj的私钥
        Element TSK=bp.getZr().newRandomElement().getImmutable(); //KMC为所有智能设备SD选择一个临时公钥
        skp.setProperty("sk_"+SD_j, Base64.getEncoder().encodeToString(skj.toBytes()));
        skp.setProperty("TSK_"+SD_j, Base64.getEncoder().encodeToString(TSK.toBytes()));
        pubProp.setProperty("SID_"+SD_j,SID_j.toString());
        storePropToFile(pubProp,publicFile);
        storePropToFile(skp,skFile);

        //for (int j = 0; j < n; j++){ //n是智能设备的数量，
            Element SIDj=bp.getZr().newRandomElement().getImmutable();//xj yj
            //skp.setProperty("a_"+ID_j+ "_" + i,Base64.getEncoder().encodeToString(ai.toBytes()));
            //pkp.setProperty("Q_"+ID_j + "_" + i,Qi.toString());
        //}
    }

    public static void Registration_U(String pairingFile,String publicFile,String pkFile,String skFile,String GW,String U_i) throws NoSuchAlgorithmException {


        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        String sstr=skp.getProperty("s_"+GW); //获取网关的私钥
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sstr)).getImmutable();
        Element ri=bp.getZr().newRandomElement().getImmutable();
        byte[] bH1_i= sha1(U_i+s.toString()+ri.toString());
        Element a=bp.getZr().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        skp.setProperty("ri_"+U_i, Base64.getEncoder().encodeToString(ri.toBytes()));

        //KMC将a发送给用户Ui
        Element PWi=bp.getZr().newRandomElement().getImmutable();
        Element BKi=bp.getZr().newRandomElement().getImmutable();
        Element RPi=bp.getZr().newRandomElement().getImmutable();
        Element UID_i=bp.getZr().newRandomElement().getImmutable();
        byte[] bUID_i=UID_i.toBytes();
        byte[] bPWi=PWi.toBytes();
        byte[] bBKi=BKi.toBytes();
        int low0 = Math.min(bUID_i.length, bPWi.length);
        int high0 = Math.max(bUID_i.length, bPWi.length);
        byte[] btemp0=new byte[high0];
        for(int i=0;i<low0;i++)
            btemp0[i]=(byte) (bUID_i[i]^bPWi[i]);
        int low1 = Math.min(btemp0.length, bBKi.length);
        int high1 = Math.max(btemp0.length, bBKi.length);
        byte[] btemp1=new byte[high1];
        for(int i=0;i<low1;i++)
            btemp1[i]=(byte) (btemp0[i]^bBKi[i]);
        byte[] bH2_i=sha1(btemp1.toString());
        byte[] ba=a.toBytes();
        int low2 = Math.min(bH2_i.length, ba.length);
        int high2 = Math.max(bH2_i.length, ba.length);
        byte[] bA=new byte[high2];
        for (int i=0;i<low2;i++)
            bA[i]= (byte) (bH2_i[i]^ba[i]);
        Element A=bp.getZr().newElementFromHash(bA,0,bA.length).getImmutable();
        byte[] bH3_i=sha1(UID_i+PWi.toString()+BKi.toString());
        Element B=bp.getZr().newElementFromHash(bH3_i,0,bH3_i.length).getImmutable();

        skp.setProperty("A_"+U_i,Base64.getEncoder().encodeToString(A.toBytes()));
        skp.setProperty("B_"+U_i,Base64.getEncoder().encodeToString(B.toBytes()));
        skp.setProperty("PW_"+U_i,Base64.getEncoder().encodeToString(PWi.toBytes()));
        skp.setProperty("BK_"+U_i,Base64.getEncoder().encodeToString(BKi.toBytes()));
        skp.setProperty("RP_"+U_i,Base64.getEncoder().encodeToString(RPi.toBytes()));
        Element l0=bp.getZr().newRandomElement().getImmutable();
        skp.setProperty("l0_"+U_i,Base64.getEncoder().encodeToString(l0.toBytes()));
        pubProp.setProperty("UID_"+U_i,UID_i.toString());
        storePropToFile(pubProp,publicFile);
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }
    public static void GW_Auth(String pairingFile,String publicFile,String pkFile,String skFile,String GW,String U_i,String SD_j) throws NoSuchAlgorithmException, IOException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Properties skp=loadPropFromFile(skFile);
        //KMC将s;SIDj TSK;UIDi ri;发送给GW
        String SID_jstr=pubProp.getProperty("SID_"+SD_j);
        Element SID_j=bp.getZr().newElementFromBytes(SID_jstr.getBytes()).getImmutable();
        String TSKstr=skp.getProperty("TSK_"+SD_j);
        Element TSK=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(TSKstr)).getImmutable();
        String UID_istr=pubProp.getProperty("UID_"+U_i);
        Element UID_i=bp.getZr().newElementFromBytes(UID_istr.getBytes()).getImmutable();
        String ristr=skp.getProperty("ri_"+U_i);
        Element ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(ristr)).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        String sstr=skp.getProperty("s_"+GW);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sstr)).getImmutable();

    }
    public static void UandSD_AKA(String pairingFile,String publicFile,String pkFile,String skFile,String authFile,String GW,String U_i,String SD_j) throws NoSuchAlgorithmException, IOException {
    //用户和智能设备借助网关的帮助实现认证
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String Sstr=pubProp.getProperty("S_"+GW);
        Element S = bp.getG1().newElementFromBytes(Sstr.getBytes()).getImmutable();
        String GIDstr=pubProp.getProperty("GID_"+GW);
        Element GID = bp.getZr().newElementFromBytes(GIDstr.getBytes()).getImmutable();
        String SID_jstr=pubProp.getProperty("SID_"+SD_j);
        Element SID_j = bp.getZr().newElementFromBytes(SID_jstr.getBytes()).getImmutable();
        Properties skp=loadPropFromFile(skFile);
        String sstr=skp.getProperty("s_"+GW);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sstr)).getImmutable();
        //用户Ui输入身份UID 密码PW 生物特征BIO
        String UID_istr=pubProp.getProperty("UID_"+U_i);
        Element UID_i=bp.getZr().newElementFromBytes(UID_istr.getBytes()).getImmutable();
        String PWistr=skp.getProperty("PW_"+U_i);
        Element PWi=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(PWistr)).getImmutable();
        Element BIOi=bp.getZr().newRandomElement().getImmutable();
        String BKistr=skp.getProperty("BK_"+U_i);
        Element BKi=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(BKistr)).getImmutable();//重构BKi
        byte[] bH3_i=sha1(UID_i+PWi.toString()+BKi.toString());
        Element B1=bp.getZr().newElementFromHash(bH3_i,0,bH3_i.length).getImmutable();
        String Bstr=skp.getProperty("B_"+U_i);
        Element B=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Bstr)).getImmutable();
        String TSKstr=skp.getProperty("TSK_"+SD_j);
        Element TSK=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(TSKstr)).getImmutable();
        String skjstr=skp.getProperty("sk_"+SD_j);
        Element skj=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(skjstr)).getImmutable();
        /*if (B1.isEqual(B)){

            out.println("Ui验证成功");
        }
        else {
            out.println("Ui验证失败");
        }*/
        Element d=bp.getZr().newRandomElement().getImmutable();
        byte[] bUID_i=UID_i.toBytes();
        byte[] bPWi=PWi.toBytes();
        byte[] bBKi=BKi.toBytes();
        int low0 = Math.min(bUID_i.length, bPWi.length);
        int high0 = Math.max(bUID_i.length, bPWi.length);
        byte[] btemp0=new byte[high0];
        for(int i=0;i<low0;i++)
            btemp0[i]=(byte) (bUID_i[i]^bPWi[i]);
        int low1 = Math.min(btemp0.length, bBKi.length);
        int high1 = Math.max(btemp0.length, bBKi.length);
        byte[] btemp1=new byte[high1];
        for(int i=0;i<low1;i++)
            btemp1[i]=(byte) (btemp0[i]^bBKi[i]);
        byte[] bH2_i=sha1(btemp1.toString());
        String Astr=skp.getProperty("A_"+U_i);
        Element A=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(Astr)).getImmutable();
        byte[] bA=A.toBytes();
        int low2 = Math.min(bH2_i.length, bA.length);
        int high2 = Math.max(bH2_i.length, bA.length);
        byte[] ba=new byte[high2];
        for (int i=0;i<low2;i++)
            ba[i]= (byte) (bH2_i[i]^bA[i]);
        Element a=bp.getZr().newElementFromHash(ba,0,ba.length).getImmutable();
        Element M1=P.powZn(a.add(d)).getImmutable();
        Element adS=S.powZn(a.add(d)).getImmutable();
        byte[] bK=sha1(adS.toString());
        Element K=bp.getZr().newElementFromHash(bK,0, bK.length).getImmutable();
        Element TS1=bp.getZr().newRandomElement().getImmutable();
        byte[] be=sha1(UID_i.toString()+GID.toString()+a.toString()+TS1.toString());
        Element e=bp.getZr().newElementFromHash(be,0, be.length).getImmutable();
        Element M2=UID_i.add(e);//Enc(uid,e)
        byte[] bM3=sha1(M1.toString()+M2.toString()+UID_i.toString()+e.toString()+TS1.toString());
        Element M3=bp.getZr().newElementFromHash(bM3,0, bM3.length).getImmutable();
        //Ui发送msg1:M123，TS1给GW
        Properties authp=loadPropFromFile(authFile);
        authp.setProperty("M1_"+U_i,M1.toString());
        authp.setProperty("M2_"+U_i,M2.toString());
        authp.setProperty("M3_"+U_i,M3.toString());
        authp.setProperty("TS1_"+U_i,TS1.toString());
        storePropToFile(authp,authFile);

        //GW收到msg1后
        byte[] bK1=sha1(M1.powZn(s).toString());
        Element K1=bp.getZr().newElementFromHash(bK1,0, bK1.length).getImmutable();
        String ristr=skp.getProperty("ri_"+U_i);
        Element ri=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(ristr)).getImmutable();
        byte[] ba1=sha1(UID_i.toString()+s.toString()+ri.toString());
        Element a1=bp.getZr().newElementFromHash(ba1,0, ba1.length).getImmutable();
        byte[] be1=sha1(UID_i.toString()+GID.toString()+a.toString()+TS1.toString());
        Element e1=bp.getZr().newElementFromHash(be1,0, be1.length).getImmutable();
        if (e1.isEqual(e)){
            //=
            out.println("成功：e1=e");
        }
        else {
            out.println("e1!=e");
        }
        byte[] bM31=sha1(M1.toString()+M2.toString()+UID_i.toString()+e.toString()+TS1.toString());
        Element M31=bp.getZr().newElementFromHash(bM31,0, bM31.length).getImmutable();
        if (M31.isEqual(M3)){
            out.println("成功：M31=M3");
        }
        else {
            out.println("M31!=M3");
        }

        byte[] bTSK1=sha1(TSK.toString());
        Element TSK1=bp.getZr().newElementFromHash(bTSK1,0, bTSK1.length).getImmutable();
        //check TSK1=TSK
        skp.setProperty("TSK_"+SD_j, Base64.getEncoder().encodeToString(TSK1.toBytes()));
        //GW广播mag2(M4,M5,TS2)给所有SD_j
        Element TS2=bp.getZr().newRandomElement().getImmutable();
        Element M4=UID_i.add(e).add(GID);//Enc()
        byte[] bM5=sha1(M4.toString()+UID_i.toString()+GID.toString()+e.toString()+TS2.toString());
        Element M5=bp.getZr().newElementFromHash(bM5,0, bM5.length).getImmutable();
        authp.setProperty("M4_"+GID,M4.toString());
        authp.setProperty("M5_"+GID,M5.toString());
        authp.setProperty("TS2_"+GID,TS2.toString());

        byte[] bM51=sha1(M4.toString()+UID_i.toString()+GID.toString()+e.toString()+TS2.toString());
        Element M51=bp.getZr().newElementFromHash(bM51,0, bM51.length).getImmutable();
        if (M51.isEqual(M5)){
            out.println("成功：M51=M5");
        }
        else {
            out.println("M51!=M5");
        }
        Element TS3=bp.getZr().newRandomElement().getImmutable();
        Element tj=bp.getZr().newRandomElement().getImmutable();
        byte[] bskj=skj.toBytes();
        byte[] btj=tj.toBytes();
        int low3 = Math.min(bskj.length, btj.length);
        int high3 = Math.max(bskj.length, btj.length);
        byte[] bcj=new byte[high3];
        for (int i=0;i<low3;i++)
            bcj[i]= (byte) (bskj[i]^btj[i]);
        Element cj=bp.getZr().newElementFromHash(bcj,0,bcj.length).getImmutable();
        Element M6j=SID_j.add(cj).getImmutable();//Enc()
        byte[] bM7j=sha1(M5.toString()+SID_j.toString()+tj.toString()+TS3.toString());
        Element M7j=bp.getZr().newElementFromHash(bM7j,0, bM7j.length).getImmutable();
        //每个SDj发送msg3j(M6j,M7j,TS3)给GW
        authp.setProperty("M6j_"+SD_j,M6j.toString());
        authp.setProperty("M7j_"+SD_j,M7j.toString());
        authp.setProperty("TS3_"+SD_j,TS3.toString());
        //GW收到msg3后验证时戳的新鲜性
        byte[] bskjj=sha1(SID_j.toString()+s.toString());
        Element skjj=bp.getZr().newElementFromHash(bskjj,0, bskjj.length).getImmutable();
        //恢复出tj,计算M7j'
        int low4 = Math.min(bskj.length, bcj.length);
        int high4 = Math.max(bskj.length, bcj.length);
        byte[] btjj=new byte[high4];
        for (int i=0;i<low4;i++)
            btjj[i]= (byte) (bskj[i]^bcj[i]);
        Element tjj=bp.getZr().newElementFromHash(btjj,0,btjj.length).getImmutable();
        byte[] bM7jj=sha1(M5.toString()+SID_j.toString()+tjj.toString()+TS3.toString());
        Element M7jj=bp.getZr().newElementFromHash(bM7jj,0, bM7jj.length).getImmutable();
        if (M7jj.isEqual(M7j)){
            out.println("成功：M7j'=M7j");
        }
        else {
            out.println("M7j'!=M7j");
        }
        Element TS4=bp.getZr().newRandomElement().getImmutable();
        Element TS5=bp.getZr().newRandomElement().getImmutable();
        Element SR=tjj.mul(1).getImmutable();
        Element U=skj.add(skj).getImmutable();
        byte[] bM8=sha1(U.toString()+TSK.toString()+TS4.toString());
        Element M8=bp.getZr().newElementFromHash(bM8,0, bM8.length).getImmutable();
        byte[] bTSK=TSK.toBytes();
        int low5 = Math.min(bM8.length, bTSK.length);
        int high5 = Math.max(bM8.length, bTSK.length);
        byte[] bM9=new byte[high5];
        for (int i=0;i<low5;i++)
            bM9[i]= (byte) (bM8[i]^bTSK[i]);
        Element M9=bp.getZr().newElementFromHash(bM9,0,bM9.length).getImmutable();
        byte[] bM10=sha1(M9.toString()+M8.toString()+TS4.toString());
        Element M10=bp.getZr().newElementFromHash(bM10,0, bM10.length).getImmutable();
        Element M11=M8.add(SR).getImmutable();
        byte[] bM12=sha1(M11.toString()+M8.toString()+SR.toString()+TS5.toString());
        Element M12=bp.getZr().newElementFromHash(bM12,0, bM12.length).getImmutable();
        //GW发送msg4=(m9,m10,TS4)给所有SDj
        authp.setProperty("M9_"+SD_j,M9.toString());
        authp.setProperty("M10_"+SD_j,M10.toString());
        authp.setProperty("TS4_"+SD_j,TS4.toString());
        //GW发送msg5=(m11,m12,TS5)给所有Ui
        authp.setProperty("M11_"+U_i,M11.toString());
        authp.setProperty("M12_"+U_i,M12.toString());
        authp.setProperty("TS5_"+U_i,TS5.toString());
        //收到消息后，SDjdo
        int low6 = Math.min(bM9.length, bTSK.length);
        int high6 = Math.max(bM9.length, bTSK.length);
        byte[] bM8_=new byte[high5];
        for (int i=0;i<low5;i++)
            bM8_[i]= (byte) (bM9[i]^bTSK[i]);
        Element M8_=bp.getZr().newElementFromHash(bM8_,0,bM8_.length).getImmutable();
        byte[] bM10_=sha1(M9.toString()+M8_.toString()+TS4.toString());
        Element M10_=bp.getZr().newElementFromHash(bM10_,0, bM10_.length).getImmutable();
        if (M10_.isEqual(M10)){
            out.println("成功：M10'=M10");
        }
        else {
            out.println("M10'!=M10");
        }
            //final，SDj计算会话密钥SKj
        byte[] bSKjtemp=sha1(UID_i+GID.toString()+e.toString()+M8_.toString());
        Element SKjtemp=bp.getZr().newElementFromHash(bSKjtemp,0, bSKjtemp.length).getImmutable();
        byte[] bSKj=sha1(SKjtemp.mul(tj).toString());
        Element SKj=bp.getZr().newElementFromHash(bSKj,0, bSKj.length).getImmutable();
        //收到消息后，Uido
        byte[] bM12_=sha1(M11.toString()+M8_.toString()+SR.toString()+TS5.toString());
        Element M12_=bp.getZr().newElementFromHash(bM12_,0, bM12_.length).getImmutable();
        if (M12_.isEqual(M12)){
            out.println("成功：M12'=M12");
        }
        else {
            out.println("M12'!=M12");
        }
            //final，Ui计算主会话密钥SK
        Element SK=SKjtemp.mul(SR).getImmutable();
        //如果Ui希望和SDj通信，则可以计算SKjby
        byte[] bSKjj=sha1(SK.toString());
        Element SKjj=bp.getZr().newElementFromHash(bSKjj,0, bSKjj.length).getImmutable();
        authp.setProperty("SKj_"+SD_j,SKj.toString());
        authp.setProperty("SK_"+U_i,SK.toString());
        storePropToFile(authp,authFile);
        storePropToFile(pubProp,publicFile);
        storePropToFile(skp,skFile);

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        /*
        指定配置文件的路径
         */
        int n=5;
        Element[] X = new Element[n+1]; //与方案统一下标，x的下标从1开始，维度为5
        Element[] Y = new Element[n+1];
        Element[] a = new Element[n+1];
        Element[] Q = new Element[n+1];
        Element[] S_k= new Element[n+1];

        String dir = "./storeFile/MingYang/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String authenFileName=dir+"auth.properties";
        String KMC = "KMC";
        String GW="Gateway";
        String SD_j="Smartdevicej";
        String U_i="Useri";


        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            setup(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,GW);
            Registration_SD(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,GW,SD_j);
            Registration_U(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,GW,U_i);
            //long start = System.currentTimeMillis();
            GW_Auth(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,GW,U_i,SD_j);
            UandSD_AKA(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,authenFileName,GW,U_i,SD_j);
            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }


    }
}
