package Our;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class Our {

    public static void setup(String pairingFile, String publicFile) { //KGC do

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element g2 = bp.getG2().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("g",g.toString());
        PubProp.setProperty("g2",g2.toString());
        storePropToFile(PubProp,publicFile);


    }


    //Registration阶段
    public static void Registration_RSU(String pairingFile,String publicFile,String pkFile,String skFile,String ID_j,Element[] a,Element[] Q,int n) throws NoSuchAlgorithmException {

        //获得g
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g2str=pubProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //为RSU生成公私钥
        Element s=bp.getZr().newRandomElement().getImmutable();
        Element U=g.powZn(s).getImmutable();
        Element W=bp.pairing(g,g2).powZn(s).getImmutable();

        for (int i = 0; i < n+1; i++){
            a[i]=bp.getZr().newRandomElement().getImmutable();
            Q[i] = g.powZn(a[i]).getImmutable();
            //skp.setProperty("a_"+ID_j+ "_" + i,Base64.getEncoder().encodeToString(ai.toBytes()));
            //pkp.setProperty("Q_"+ID_j + "_" + i,Qi.toString());
        }
        pkp.setProperty("W_"+ID_j,W.toString());
        skp.setProperty("U_"+ID_j,Base64.getEncoder().encodeToString(U.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }

    public static void Registration_V(String pairingFile,String publicFile,String pkFile,String skFile,String ID_j,String ID_i,Element[] a, Element[] Q,Element[] S_k,Element[] X) throws NoSuchAlgorithmException {


        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //获得RSUj的密钥
        Properties skp=loadPropFromFile(skFile);
        String Ustr=skp.getProperty("U_"+ID_j);
        Element U=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Ustr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        //为车辆生成公私钥
        Element z_i=bp.getZr().newRandomElement().getImmutable();
        Element Z_i=g.powZn(z_i).getImmutable();
            //为车辆生成假名
        byte[] bID_i=ID_i.getBytes();
        byte[] bH0_i=sha1(a[0].toString()+Z_i.toString());
        int h = Math.max(bH0_i.length, bID_i.length);
        int l = Math.min(bH0_i.length, bID_i.length);
        byte[] bPID_i=new byte[h];
        for (int i=0;i<l;i++)
            bPID_i[i]= (byte) (bH0_i[i]^bID_i[i]);
        Element PID_i=bp.getG1().newElementFromHash(bPID_i,0,bPID_i.length).getImmutable();
        pkp.setProperty("PID_"+ID_i,PID_i.toString());

        byte[] bH_i=sha1(ID_j+PID_i.toString()+X.toString());
        Element K0i=bp.getG2().newElementFromHash(bH_i,0,bH_i.length).getImmutable();
        Element K1i=U.mul(K0i).powZn(a[0]);
        for (int i = 1; i < X.length; i++) {
            X[i]=bp.getZr().newRandomElement().getImmutable();
        }

        for (int k=2;k<X.length;k++){
            S_k[k]= K0i.powZn(a[k].sub(a[1].mul(X[k]).div(X[1]))).getImmutable(); //如何存数组
            //skp.setProperty("ai_"+ID_j+ "_" + k+1,Base64.getEncoder().encodeToString(S_k[k].toBytes()));
        }
        skp.setProperty("K0_"+ID_i,Base64.getEncoder().encodeToString(K0i.toBytes()));
        skp.setProperty("K1_"+ID_i,Base64.getEncoder().encodeToString(K1i.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }
    public static void RSU_V_onetomanyAuth(String pairingFile,String publicFile,String pkFile,String skFile,String ID_j,String ID_i,Element[] a, Element[] Q,Element[] S_k,Element[] X,Element[] Y) throws NoSuchAlgorithmException, IOException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g=bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g2str=pubProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        //获取车辆假名
        String PID_istr=pkp.getProperty("PID_"+ID_i);//获取属性
        Element PID_i=bp.getG1().newElementFromBytes(PID_istr.getBytes()).getImmutable();//字符串转换为element
        //获取RSU公钥
        String Wstr=pkp.getProperty("W_"+ID_j);
        Element W=bp.getGT().newElementFromBytes(Wstr.getBytes()).getImmutable();
        //获取RSU和车辆私钥
        Properties skp=loadPropFromFile(skFile);
        String Ustr=skp.getProperty("U_"+ID_j);
        Element U=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Ustr)).getImmutable();
        String K0istr=skp.getProperty("d_"+ID_i);
        Element K0i=bp.getG2().newElementFromBytes(Base64.getDecoder().decode(K0istr)).getImmutable();
        String K1istr=skp.getProperty("x_"+ID_i);
        Element K1i=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(K1istr)).getImmutable();

        //RSU向车辆发消息
        Element t1=bp.getZr().newRandomElement().getImmutable();
        Element r=bp.getZr().newRandomElement().getImmutable();
        Element M=bp.getGT().newRandomElement().getImmutable();
        Element T1=g.powZn(t1).getImmutable();
        Element C0=M.mul(W.powZn(r)).getImmutable();
        Element C_temp=Q[0].getImmutable();
        for (int i = 1; i < Y.length; i++) {
            Y[i]=bp.getZr().newRandomElement().getImmutable();
        }
        for(int i=1;i<X.length;i++){
            C_temp=C_temp.mul(Q[i].powZn(Y[i])).getImmutable();
        }
        Element C1=C_temp.powZn(r).getImmutable();
        Element C2=g2.powZn(r).getImmutable();
        //处理RSU公钥中的多个元素，作为哈希函数h1的输入：begin
            // 假设你已经有了计算SHA-1哈希的方法sha1，它接受一个字符串并返回一个byte[]
            byte[] bh1_Qi_Initial = sha1(Q[0].toString()); // 计算Q[0]的哈希
            // 使用ByteArrayOutputStream来累加哈希值
            ByteArrayOutputStream join = new ByteArrayOutputStream();
            join.write(bh1_Qi_Initial); // 写入初始哈希值
            // 遍历Q数组
            for(int i = 1; i < X.length; i++){ // 假设X是定义了你要处理多少个Q元素的数组或长度
                byte[] bh1_CurrentQi = sha1(Q[i].toString()); // 计算当前Q[i]的哈希值
                join.write(bh1_CurrentQi); // 将当前哈希值追加到ByteArrayOutputStream中
            }
            // 获取最终的字节数组
            byte[] bh1_Qi = join.toByteArray();
            Element h1_Qi=bp.getZr().newElementFromHash(bh1_Qi,0,bh1_Qi.length).getImmutable();
        // 现在bh1_Qi包含了Q[0]到Q[X.length]所有元素的哈希值的连接 end
        //在加上哈希函数剩余的输入
        byte[] bh1_else=sha1(T1.toString()+M.toString()+ W.toString());
        join.write(bh1_else);// 将当前哈希值追加到ByteArrayOutputStream中
        byte[] bh1 = join.toByteArray();
        Element h1=bp.getZr().newElementFromHash(bh1,0,bh1.length).getImmutable();
        Element sigma_j= t1.add(a[0].mul(h1));
        Element Gamma1=bp.getG1().newRandomElement().getImmutable();
        Element alpha=bp.getZr().newRandomElement().getImmutable();
        Element P1=g.powZn(alpha).getImmutable();

        //车辆收到消息后，如果内积匹配，=0
        Element temp= K1i.getImmutable();
        for(int i=2;i<X.length;i++){
            temp=temp.mul(S_k[i].powZn(Y[i])).getImmutable();
        }
        Element Ri= bp.pairing(temp,C2).div(bp.pairing(C1,K0i)).getImmutable();
        Element M_=C0.mul(Ri.invert()).getImmutable();//M_=M
        //车辆进一步验证RSU的签名
        Element lgsigma_j=g.powZn(sigma_j).getImmutable();
        Element rgsigma_j=T1.add(Q[0].powZn(h1)).getImmutable();
        if (lgsigma_j.isEqual(rgsigma_j)){
            //如果车辆验证成功
            out.println("车辆验证成功");
        }
        else {
            out.println("车辆验证失败");
        }
        //then 车辆计算会话密钥,并将(K,Gamma2)发送给RSU
        Element Gamma2=bp.getG1().newRandomElement().getImmutable();
        Element beta=bp.getZr().newRandomElement().getImmutable();
        Element P2=g.powZn(beta).getImmutable();
        Element K=P1.powZn(beta).getImmutable();

        //RSU收到车辆的消息后，认为车辆合法，并计算会话密钥
        Element K_=P2.powZn(alpha).getImmutable();


        if (K.isEqual(K_)){
            out.println("会话密钥协商成功");
        }
        else {
            out.println("会话密钥协商失败");
        }
        skp.setProperty("session key",Base64.getEncoder().encodeToString(K.toBytes()));
        skp.setProperty("session key_",Base64.getEncoder().encodeToString(K_.toBytes()));

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        /*
        指定配置文件的路径
         */
        int n=5;
        Element[] X = new Element[n+1]; //与方案统一下标，x的下标从1开始，维度为5
        Element[] Y = new Element[n+1];
        Element[] a = new Element[n+1];
        Element[] Q = new Element[n+1];
        Element[] S_k= new Element[n+1];

        String dir = "./storeFile/Our/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String certificateFileName=dir+"pid.properties";
        String verifyFileName=dir+"auth.properties";
        String KGC = "KGC";
        String ID_i="Vhiclei";
        String ID_j="RSUj";

        for (int i = 0; i < 10; i++) {
            setup(pairingParametersFileName,publicParameterFileName);
            long start = System.currentTimeMillis();
            Registration_RSU(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,ID_j,a,Q,n);
            Registration_V(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,ID_j,ID_i,a,Q,S_k,X);
            RSU_V_onetomanyAuth(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,ID_j,ID_i,a,Q,S_k,X,Y);
            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }


    }
}
