package Wang;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

import static java.lang.System.out;

public class Wang {


    public static void setup0(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void setup(String pairingFile, String publicFile,String mskFile,String KGC_i) {
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGCA、B的主私钥
        Element s_i = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC_i, Base64.getEncoder().encodeToString(s_i.toBytes()));//element和string类型之间的转换需要通过bytes
        storePropToFile(mskProp, mskFile);

        //设置KGCA、B的主公钥
        Element P_pubi = P.powZn(s_i).getImmutable();
        PubProp.setProperty("P_pub_"+KGC_i, P_pubi.toString());
        storePropToFile(PubProp,publicFile);
    }


    //Registration阶段
    public static void Registration_User(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC_i,String ID_i) throws NoSuchAlgorithmException {

        //获得KGC的主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        //String P_pubistr=pubProp.getProperty("P_pub_"+KGC_i);
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //Element P_pubi = bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC_i);
        Element s_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //为U生成公私钥
        //U does
        Element r_i=bp.getZr().newRandomElement().getImmutable();
        Element R_i=P.powZn(r_i).getImmutable();
        //KGC does
        Element k_i=bp.getZr().newRandomElement().getImmutable();
        Element P_i=P.powZn(k_i).getImmutable();
        //为车辆生成假名

        byte[] bH1_i=sha1(ID_i+P_i.toString()+R_i.toString());
        Element PID_i=bp.getG1().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element D_i=PID_i.powZn(s_i).getImmutable();

        pkp.setProperty("PID_"+ID_i,PID_i.toString());

        pkp.setProperty("R_"+ID_i,R_i.toString());
        skp.setProperty("D_"+ID_i,Base64.getEncoder().encodeToString(D_i.toBytes()));
        skp.setProperty("r_"+ID_i,Base64.getEncoder().encodeToString(r_i.toBytes()));
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }


    public static void AKA(String pairingFile,String publicFile,String pkFile,String skFile,String KGC_A,String KGC_B,String ID_i,String ID_j) throws NoSuchAlgorithmException {
        //车辆间跨域认证和密钥协商
        //获取KGCA、B的主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC_A);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pubi = bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();

        String P_pubjstr=pubProp.getProperty("P_pub_"+KGC_A);
        Element P_pubj = bp.getG1().newElementFromBytes(P_pubjstr.getBytes()).getImmutable();

        //获取车辆i,j的假名
        Properties pkp=loadPropFromFile(pkFile);
        String PID_istr=pkp.getProperty("PID_"+ID_i);//获取属性
        Element PID_i=bp.getG1().newElementFromBytes(PID_istr.getBytes()).getImmutable();//字符串转换为element
        String PID_jstr=pkp.getProperty("PID_"+ID_j);//获取属性
        Element PID_j=bp.getG1().newElementFromBytes(PID_jstr.getBytes()).getImmutable();//字符串转换为element

        //获取用户i,j的公钥 和私钥
        String R_istr=pkp.getProperty("R_"+ID_i);
        Element R_i=bp.getG1().newElementFromBytes(R_istr.getBytes()).getImmutable();
        String R_jstr=pkp.getProperty("R_"+ID_j);
        Element R_j=bp.getG1().newElementFromBytes(R_jstr.getBytes()).getImmutable();

        Properties skp=loadPropFromFile(skFile);
        String D_istr=skp.getProperty("D_"+ID_i);
        Element D_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(D_istr)).getImmutable();
        String r_istr=skp.getProperty("r_"+ID_i);
        Element r_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(r_istr)).getImmutable();

        String D_jstr=skp.getProperty("D_"+ID_j);
        Element D_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(D_jstr)).getImmutable();
        String r_jstr=skp.getProperty("r_"+ID_j);
        Element r_j=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(r_jstr)).getImmutable();

        Element KGCdomainB= bp.getG1().newElementFromBytes(KGC_B.getBytes()).getImmutable();
        Element KGCdomainA= bp.getG1().newElementFromBytes(KGC_A.getBytes()).getImmutable();
        //用户U V跨域通信前先完成相互认证！没有对N_U、N_V的上链操作，后续通信还要涉及到这两个参数，所以这两段过程应该在一个环节内
        Element N_i=bp.getG1().newRandomElement().getImmutable();
        Element N_j=bp.getG1().newRandomElement().getImmutable();
        Element text_i=bp.getG1().newRandomElement().getImmutable();
        Element text_j=bp.getG1().newRandomElement().getImmutable();
        Element m0_i=N_i.add(KGCdomainA.add(PID_i.add(text_i))).getImmutable();
        byte[] bh20_i=sha1(PID_i.toString()+P_pubi.toString()+ R_i.toString()+m0_i.toString());
        Element h20_i=bp.getZr().newElementFromHash(bh20_i,0,bh20_i.length).getImmutable();
        byte[] bh30_i=sha2(PID_i.toString()+P_pubi.toString()+ R_i.toString()+m0_i.toString());
        Element h30_i=bp.getZr().newElementFromHash(bh20_i,0,bh30_i.length).getImmutable();
        Element sigma0_i= h20_i.mul(D_i).add(h30_i.mul(r_i)).getImmutable();
        //Element TokenUV_i= sigma0_i.add(m0_i).getImmutable();
        byte[] bh_i=sha1(m0_i.toString()+sigma0_i.toString());
        Element TokenUV_i=bp.getZr().newElementFromHash(bh_i,0,bh_i.length).getImmutable();

        Element m0_j=N_j.add(KGCdomainB.add(PID_j.add(text_j))).getImmutable();
        byte[] bh20_j=sha1(PID_j.toString()+P_pubj.toString()+ R_j.toString()+m0_j.toString());
        Element h20_j=bp.getZr().newElementFromHash(bh20_i,0,bh20_i.length).getImmutable();
        byte[] bh30_j=sha2(PID_j.toString()+P_pubj.toString()+ R_j.toString()+m0_j.toString());
        Element h30_j=bp.getZr().newElementFromHash(bh20_j,0,bh30_j.length).getImmutable();
        Element sigma0_j=h20_j.mul(D_j).add(h30_j.mul(r_j)).getImmutable();
        //Element TokenUV_j=m0_j.add(sigma0_j).getImmutable();
        byte[] bh_j=sha1(m0_j.toString()+sigma0_j.toString());
        Element TokenUV_j=bp.getZr().newElementFromHash(bh_j,0,bh_j.length).getImmutable();

        //用户U发送通信请求(PIDU,reqinfA)
        Element TSA_i=bp.getG1().newRandomElement().getImmutable();
        Element descripV_i=bp.getG1().newRandomElement().getImmutable();
        Element reqinfA_i= KGCdomainB.add(descripV_i.add(TSA_i)).getImmutable();
        //BAS_A区块链服务器验证车辆的假名PIDU,并产生应答(ID_BAS,respinfA)
        Element paramB_j=bp.getG1().newRandomElement().getImmutable();
        Element respinfA_j= KGCdomainB.add(paramB_j.add(descripV_i.add(PID_j.add(R_j.add(TSA_i))))).getImmutable();
        //U收到BAS应答后产生(m,σ）
        Element r2_i=bp.getZr().newRandomElement().getImmutable();
        Element pk2_i=P.powZn(r2_i).getImmutable();
        Element m_i=N_i.add(KGCdomainA.add(PID_i.add(pk2_i))).getImmutable();
        byte[] bh2_i=sha1(PID_i.toString()+P_pubi.toString()+ R_i.toString()+m_i.toString());
        Element h2_i=bp.getZr().newElementFromHash(bh2_i,0,bh2_i.length).getImmutable();
        byte[] bh3_i=sha2(PID_i.toString()+P_pubi.toString()+ R_i.toString()+m_i.toString());
        Element h3_i=bp.getZr().newElementFromHash(bh2_i,0,bh3_i.length).getImmutable();
        Element sigma_i= h2_i.mul(D_i).add(h3_i.mul(r_i)).getImmutable();

        //用户V收到(m,σ)后产生通信请求(PIDV,reqinfB)
        Element TSB_j=bp.getG1().newRandomElement().getImmutable();
        Element reqinfB_j= KGCdomainA.add(PID_i.add(TSB_j)).getImmutable();
        //BAS_B验证PIDV PIDU,产生应答(ID_BAS,respinfB)
        Element paramA_i=bp.getG1().newRandomElement().getImmutable();
        Element respinfB_j= KGCdomainB.add(paramA_i.add(descripV_i.add(PID_j.add(R_j.add(TSA_i))))).getImmutable();
        //V收到BAS应答后产生(m,σ)和会话密钥SK

        Element r2_j=bp.getZr().newRandomElement().getImmutable();
        Element pk2_j=P.powZn(r2_i).getImmutable();
        Element m_j=N_j.add(KGCdomainB.add(P_pubj.add(pk2_j))).getImmutable();
        byte[] bh2_j=sha1(PID_j.toString()+P_pubj.toString()+ R_j.toString()+m_j.toString());
        Element h2_j=bp.getZr().newElementFromHash(bh2_j,0,bh2_j.length).getImmutable();
        byte[] bh3_j=sha2(PID_j.toString()+P_pubj.toString()+ R_j.toString()+m_j.toString());
        Element h3_j=bp.getZr().newElementFromHash(bh2_j,0,bh3_j.length).getImmutable();
        Element sigma_j= h2_j.mul(D_j).add(h3_j.mul(r_j)).getImmutable();
        Element SK_UVj=pk2_i.powZn(r2_j).getImmutable();
        //final,U验证V的签名，并产生SK
        Element SK_UVi=pk2_j.powZn(r2_i).getImmutable();
        skp.setProperty("SK_UV_",SK_UVi.toString());

        skp.setProperty("SK_UV_",SK_UVj.toString());
        storePropToFile(skp,skFile);

    }




    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Wang/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String KGC_A = "KGC_A";
        String KGC_B="KGC_B";
        String ID_i="U";
        String ID_j="V";

        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            setup0(pairingParametersFileName,publicKeyFileName);
            setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC_A);
            setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC_B);
            Registration_User(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC_A,ID_i);
            Registration_User(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC_B,ID_j);
            AKA(pairingParametersFileName,publicParameterFileName,publicKeyFileName,secretKeyFileName,KGC_A,KGC_B,ID_i,ID_j);
            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }



    }
}
